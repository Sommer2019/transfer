// streamdeck-config.js
// Konfiguration für alle Streamdeck-Buttons

const path = require('path');

module.exports = {
  // URLs für Deploy QA und Dev - hier eintragen!
  urls: {
    deployQa: [
      'https://example.com/qa-dashboard',
      'https://example.com/qa-logs',
      'https://example.com/qa-monitoring',
      'https://example.com/qa-deploy',
    ],
    deployDev: [
      'https://example.com/dev-dashboard',
      'https://example.com/dev-logs',
      'https://example.com/dev-monitoring',
      'https://example.com/dev-deploy',
    ]
  },

  // 3 Seiten zu je 5x3 = 15 Buttons
  pages: {
    // PAGE 1: Browser & Deploy
    page1: [
      {
        index: 0,
        name: 'Teams Open',
        command: 'start ms-teams:',
        color: { r: 87, g: 166, b: 238 },
        icon: path.join(__dirname, 'icons/teams-open.png')
      },
      {
        index: 1,
        name: 'Teams Close',
        command: 'taskkill /IM Teams.exe /F',
        color: { r: 50, g: 100, b: 180 },
        icon: path.join(__dirname, 'icons/teams-close.png')
      },
      {
        index: 2,
        name: 'Outlook Open',
        command: 'start outlook:',
        color: { r: 0, g: 120, b: 215 },
        icon: path.join(__dirname, 'icons/outlook-open.png')
      },
      {
        index: 3,
        name: 'Outlook Close',
        command: 'taskkill /IM OUTLOOK.EXE /F',
        color: { r: 50, g: 80, b: 140 },
        icon: path.join(__dirname, 'icons/outlook-close.png')
      },
      {
        index: 4,
        name: 'Page 2: IntelliJ',
        type: 'page',
        targetPage: 1,
        color: { r: 100, g: 100, b: 100 },
        icon: path.join(__dirname, 'icons/next-page.png')
      },
      {
        index: 5,
        name: 'Deploy to QA',
        type: 'multiurl',
        urls: 'deployQa',
        color: { r: 200, g: 100, b: 200 },
        icon: path.join(__dirname, 'icons/deploy-qa.png')
      },
      {
        index: 6,
        name: 'Deploy to Dev',
        type: 'multiurl',
        urls: 'deployDev',
        color: { r: 150, g: 100, b: 200 },
        icon: path.join(__dirname, 'icons/deploy-dev.png')
      },
      {
        index: 7,
        name: 'Edge Open',
        command: 'start msedge',
        color: { r: 0, g: 120, b: 220 },
        icon: path.join(__dirname, 'icons/edge-open.png')
      },
      {
        index: 8,
        name: 'Edge Close',
        command: 'taskkill /IM msedge.exe /F',
        color: { r: 50, g: 70, b: 130 },
        icon: path.join(__dirname, 'icons/edge-close.png')
      },
      {
        index: 9,
        name: 'Lock PC',
        command: 'rundll32.exe user32.dll,LockWorkStation',
        color: { r: 200, g: 0, b: 200 },
        icon: path.join(__dirname, 'icons/lock.png')
      },
      {
        index: 10,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 11,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 12,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 13,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 14,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
    ],

    // PAGE 2: IntelliJ
    page2: [
      {
        index: 0,
        name: 'Format Code',
        hotkey: { key: 'l', modifiers: ['ctrl', 'alt'] },
        color: { r: 100, g: 150, b: 255 },
        icon: path.join(__dirname, 'icons/format.png')
      },
      {
        index: 1,
        name: 'Optimize Imports',
        hotkey: { key: 'o', modifiers: ['ctrl', 'alt'] },
        color: { r: 100, g: 200, b: 150 },
        icon: path.join(__dirname, 'icons/imports.png')
      },
      {
        index: 2,
        name: 'Fix Code',
        hotkey: { key: 'Return', modifiers: ['alt'] },
        color: { r: 255, g: 150, b: 0 },
        icon: path.join(__dirname, 'icons/fix.png')
      },
      {
        index: 3,
        name: 'Run',
        hotkey: { key: 'F10' },
        color: { r: 0, g: 200, b: 100 },
        icon: path.join(__dirname, 'icons/run.png')
      },
      {
        index: 4,
        name: 'Page 3: Teams',
        type: 'page',
        targetPage: 2,
        color: { r: 100, g: 100, b: 100 },
        icon: path.join(__dirname, 'icons/next-page.png')
      },
      {
        index: 5,
        name: 'Update Project',
        hotkey: { key: 't', modifiers: ['ctrl'] },
        color: { r: 255, g: 100, b: 0 },
        icon: path.join(__dirname, 'icons/update.png')
      },
      {
        index: 6,
        name: 'Push Commits',
        hotkey: { key: 'k', modifiers: ['ctrl', 'shift'] },
        color: { r: 0, g: 200, b: 100 },
        icon: path.join(__dirname, 'icons/push.png')
      },
      {
        index: 7,
        name: 'Copilot',
        hotkey: { key: '\\', modifiers: ['ctrl'] },
        color: { r: 100, g: 200, b: 255 },
        icon: path.join(__dirname, 'icons/copilot.png')
      },
      {
        index: 8,
        name: 'Debug',
        hotkey: { key: 'F9' },
        color: { r: 200, g: 0, b: 100 },
        icon: path.join(__dirname, 'icons/debug.png')
      },
      {
        index: 9,
        name: 'Find/Replace',
        hotkey: { key: 'h', modifiers: ['ctrl'] },
        color: { r: 150, g: 150, b: 255 },
        icon: path.join(__dirname, 'icons/find-replace.png')
      },
      {
        index: 10,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 11,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 12,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 13,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 14,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
    ],

    // PAGE 3: Teams
    page3: [
      {
        index: 0,
        name: 'Mute',
        hotkey: { key: 'm', modifiers: ['ctrl'] },
        color: { r: 255, g: 0, b: 0 },
        icon: path.join(__dirname, 'icons/mute.png')
      },
      {
        index: 1,
        name: 'Unmute',
        hotkey: { key: 'm', modifiers: ['ctrl'] },
        color: { r: 0, g: 255, b: 0 },
        icon: path.join(__dirname, 'icons/unmute.png')
      },
      {
        index: 2,
        name: 'Cam On',
        hotkey: { key: 'k', modifiers: ['ctrl'] },
        color: { r: 0, g: 100, b: 255 },
        icon: path.join(__dirname, 'icons/cam-on.png')
      },
      {
        index: 3,
        name: 'Cam Off',
        hotkey: { key: 'k', modifiers: ['ctrl'] },
        color: { r: 100, g: 100, b: 100 },
        icon: path.join(__dirname, 'icons/cam-off.png')
      },
      {
        index: 4,
        name: 'Page 1: Browser',
        type: 'page',
        targetPage: 0,
        color: { r: 100, g: 100, b: 100 },
        icon: path.join(__dirname, 'icons/prev-page.png')
      },
      {
        index: 5,
        name: 'Screen Share',
        hotkey: { key: 'e', modifiers: ['ctrl', 'alt'] },
        color: { r: 255, g: 165, b: 0 },
        icon: path.join(__dirname, 'icons/share.png')
      },
      {
        index: 6,
        name: 'Unshare',
        hotkey: { key: 'e', modifiers: ['ctrl', 'alt'] },
        color: { r: 100, g: 100, b: 100 },
        icon: path.join(__dirname, 'icons/unshare.png')
      },
      {
        index: 7,
        name: 'Hangup',
        hotkey: { key: 'Escape' },
        color: { r: 200, g: 0, b: 0 },
        icon: path.join(__dirname, 'icons/hangup.png')
      },
      {
        index: 8,
        name: 'Raise Hand',
        hotkey: { key: 'k', modifiers: ['ctrl', 'shift'] },
        color: { r: 255, g: 200, b: 0 },
        icon: path.join(__dirname, 'icons/raise-hand.png')
      },
      {
        index: 9,
        name: 'Chat Open',
        hotkey: { key: 'o', modifiers: ['ctrl', 'shift'] },
        color: { r: 100, g: 200, b: 255 },
        icon: path.join(__dirname, 'icons/chat.png')
      },
      {
        index: 10,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 11,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 12,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 13,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
      {
        index: 14,
        name: 'Empty',
        color: { r: 30, g: 30, b: 30 },
        icon: null
      },
    ],
  }
};
