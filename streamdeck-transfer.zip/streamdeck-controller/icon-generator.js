// icon-generator.js
const fs = require('fs');
const path = require('path');

// Versuchen Canvas zu laden, fallback auf jimp wenn nicht vorhanden
let Canvas;
try {
  Canvas = require('canvas');
} catch (e) {
  console.warn('⚠️  Canvas nicht installiert. Verwende einfache Farben ohne Icons.');
  Canvas = null;
}

const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

/**
 * Erstelle ein Icon mit Emoji + Label
 */
function createIcon(emoji, label, color, outputFile) {
  if (!Canvas) {
    console.log(`  ⏭️  Überspringe Icon für "${label}" (Canvas nicht vorhanden)`);
    return;
  }

  try {
    const canvas = Canvas.createCanvas(72, 72);
    const ctx = canvas.getContext('2d');

    // Hintergrund (Farbe)
    ctx.fillStyle = `rgb(${color.r}, ${color.g}, ${color.b})`;
    ctx.fillRect(0, 0, 72, 72);

    // Emoji groß in der Mitte
    if (emoji) {
      ctx.font = 'bold 48px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(emoji, 36, 28);
    }

    // Label klein darunter
    if (label) {
      ctx.font = '10px Arial';
      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      
      // Text kürzen wenn zu lang
      const shortLabel = label.length > 12 ? label.substring(0, 10) + '..' : label;
      ctx.fillText(shortLabel, 36, 54);
    }

    // Speichern
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(outputFile, buffer);
    console.log(`  ✅ ${label.padEnd(15)} → ${path.basename(outputFile)}`);
  } catch (err) {
    console.error(`  ❌ Icon-Fehler für "${label}":`, err.message);
  }
}

/**
 * Alle Icons generieren
 */
function generateAllIcons() {
  console.log('\n🎨 Generiere Icons...\n');

  const icons = [
    // PAGE 1: Browser & Deploy
    { emoji: '🔵', label: 'Teams On', color: { r: 87, g: 166, b: 238 }, file: 'teams-open.png' },
    { emoji: '🔵', label: 'Teams Off', color: { r: 50, g: 100, b: 180 }, file: 'teams-close.png' },
    { emoji: '📧', label: 'Outlook On', color: { r: 0, g: 120, b: 215 }, file: 'outlook-open.png' },
    { emoji: '📧', label: 'Outlook Off', color: { r: 50, g: 80, b: 140 }, file: 'outlook-close.png' },
    { emoji: '▶️', label: 'Page 2', color: { r: 100, g: 100, b: 100 }, file: 'next-page.png' },
    { emoji: '🚀', label: 'QA Deploy', color: { r: 200, g: 100, b: 200 }, file: 'deploy-qa.png' },
    { emoji: '🚀', label: 'Dev Deploy', color: { r: 150, g: 100, b: 200 }, file: 'deploy-dev.png' },
    { emoji: '🌐', label: 'Edge On', color: { r: 0, g: 120, b: 220 }, file: 'edge-open.png' },
    { emoji: '🌐', label: 'Edge Off', color: { r: 50, g: 70, b: 130 }, file: 'edge-close.png' },
    { emoji: '🔒', label: 'Lock', color: { r: 200, g: 0, b: 200 }, file: 'lock.png' },
    
    // PAGE 2: IntelliJ
    { emoji: '🎨', label: 'Format', color: { r: 100, g: 150, b: 255 }, file: 'format.png' },
    { emoji: '📦', label: 'Imports', color: { r: 100, g: 200, b: 150 }, file: 'imports.png' },
    { emoji: '🔧', label: 'Fix', color: { r: 255, g: 150, b: 0 }, file: 'fix.png' },
    { emoji: '▶️', label: 'Run', color: { r: 0, g: 200, b: 100 }, file: 'run.png' },
    { emoji: '▶️', label: 'Page 3', color: { r: 100, g: 100, b: 100 }, file: 'next-page.png' },
    { emoji: '♻️', label: 'Update', color: { r: 255, g: 100, b: 0 }, file: 'update.png' },
    { emoji: '⬆️', label: 'Push', color: { r: 0, g: 200, b: 100 }, file: 'push.png' },
    { emoji: '✨', label: 'Copilot', color: { r: 100, g: 200, b: 255 }, file: 'copilot.png' },
    { emoji: '🐛', label: 'Debug', color: { r: 200, g: 0, b: 100 }, file: 'debug.png' },
    { emoji: '🔍', label: 'Find', color: { r: 150, g: 150, b: 255 }, file: 'find-replace.png' },
    
    // PAGE 3: Teams
    { emoji: '🔴', label: 'Mute', color: { r: 255, g: 0, b: 0 }, file: 'mute.png' },
    { emoji: '🟢', label: 'Unmute', color: { r: 0, g: 255, b: 0 }, file: 'unmute.png' },
    { emoji: '📹', label: 'Cam On', color: { r: 0, g: 100, b: 255 }, file: 'cam-on.png' },
    { emoji: '📹', label: 'Cam Off', color: { r: 100, g: 100, b: 100 }, file: 'cam-off.png' },
    { emoji: '◀️', label: 'Page 1', color: { r: 100, g: 100, b: 100 }, file: 'prev-page.png' },
    { emoji: '🖥️', label: 'Share', color: { r: 255, g: 165, b: 0 }, file: 'share.png' },
    { emoji: '🖥️', label: 'Unshare', color: { r: 100, g: 100, b: 100 }, file: 'unshare.png' },
    { emoji: '☎️', label: 'Hangup', color: { r: 200, g: 0, b: 0 }, file: 'hangup.png' },
    { emoji: '✋', label: 'Raise Hand', color: { r: 255, g: 200, b: 0 }, file: 'raise-hand.png' },
    { emoji: '💬', label: 'Chat', color: { r: 100, g: 200, b: 255 }, file: 'chat.png' },
  ];

  icons.forEach(icon => {
    const outputPath = path.join(iconsDir, icon.file);
    createIcon(icon.emoji, icon.label, icon.color, outputPath);
  });

  console.log('\n✅ Icons fertig!\n');
}

module.exports = { generateAllIcons, createIcon, iconsDir };

// Wenn direkt aufgerufen
if (require.main === module) {
  generateAllIcons();
}
