@echo off
REM Streamdeck Controller Starter für Windows

cd /d "%~dp0"

echo.
echo ========================================
echo  Streamdeck Controller
echo ========================================
echo.

REM Prüfen ob node.js installiert ist
node --version >nul 2>&1
if errorlevel 1 (
    echo FEHLER: Node.js nicht gefunden!
    echo Bitte Node.js installieren: https://nodejs.org
    pause
    exit /b 1
)

REM Dependencies prüfen
if not exist "node_modules" (
    echo 📦 Installiere Dependencies...
    call npm install
    echo.
)

REM Controller starten
echo 🎮 Starte Streamdeck Controller...
echo.
echo Drücke Ctrl+C zum Beenden
echo.
call npm start

pause
