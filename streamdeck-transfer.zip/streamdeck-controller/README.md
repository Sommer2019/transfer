# 🎮 Streamdeck Controller – 3 Seiten (5x3 Buttons)

Multi-Page Streamdeck-Steuerung: **Browser & Deploy** | **IntelliJ** | **Teams**

Wechsel zwischen Seiten mit den Navigations-Buttons.

---

## Setup

### 1. Installation

```bash
npm run setup
```

### 2. Start

```bash
npm start
```

oder `start.bat` doppelklicken.

---

## 📄 PAGE 1: Browser & Deploy (Seite 1)

Öffne Apps, Deploy-Dashboards und verwalte Browser/Mail.

| Button | Icon | Aktion | Farbe |
|--------|------|--------|-------|
| [0] Teams Open | 🔵 | Öffne Teams | Blau |
| [1] Teams Close | 🔵 | Schließe Teams | Dunkelblau |
| [2] Outlook Open | 📧 | Öffne Outlook | Blau |
| [3] Outlook Close | 📧 | Schließe Outlook | Dunkelblau |
| **[4] → Seite 2** | **▶️** | **Zu IntelliJ** | **Grau** |
| [5] Deploy QA | 🚀 | 4 QA-URLs öffnen | Magenta |
| [6] Deploy Dev | 🚀 | 4 Dev-URLs öffnen | Lila |
| [7] Edge Open | 🌐 | Öffne Edge | Blau |
| [8] Edge Close | 🌐 | Schließe Edge | Dunkelblau |
| [9] Lock PC | 🔒 | PC sperren | Magenta |

**Pro-Tipp:** Teams/Outlook öffnen, schnell Deploy-URLs laden, Edge zur Seite nebendran.

---

## 💻 PAGE 2: IntelliJ (Seite 2)

Alle IntelliJ-Shortcuts für optimalen Code-Flow.

| Button | Icon | Hotkey | Farbe | Was es tut |
|--------|------|--------|-------|-----------|
| [0] Format Code | 🎨 | Ctrl+Alt+L | Hellblau | Code formatieren (Indent + Spacing) |
| [1] Optimize Imports | 📦 | Ctrl+Alt+O | Grün | Unused Imports entfernen |
| [2] Fix Code | 🔧 | Alt+Return | Orange | Intention Actions / Quick Fixes |
| [3] Run | ▶️ | F10 | Grün | Build & Run |
| **[4] → Seite 3** | **▶️** | - | **Grau** | **Zu Teams** |
| [5] Update Project | ♻️ | Ctrl+T | Orange | Git Pull + Auto-Merge |
| [6] Push Commits | ⬆️ | Ctrl+Shift+K | Grün | Git Push |
| [7] Copilot | ✨ | Ctrl+\ | Hellblau | GitHub Copilot Chat |
| [8] Debug | 🐛 | F9 | Rosa | Start Debugger |
| [9] Find/Replace | 🔍 | Ctrl+H | Violett | Find & Replace Dialog |

**Workflow:**
1. Code schreiben
2. `[0]` Format + `[1]` Optimize → Sauberer Code
3. `[2]` Fix → Warnings beheben
4. `[5]` Update + `[6]` Push → Pushen

---

## 📞 PAGE 3: Teams (Seite 3)

Teams-Kontrolle für Meetings.

| Button | Icon | Hotkey | Farbe | Was es tut |
|--------|------|--------|-------|-----------|
| [0] Mute | 🔴 | Ctrl+M | Rot | Mikrofon aus |
| [1] Unmute | 🟢 | Ctrl+M | Grün | Mikrofon an |
| [2] Cam On | 📹 | Ctrl+K | Blau | Kamera an |
| [3] Cam Off | 📹 | Ctrl+K | Grau | Kamera aus |
| **[4] ← Seite 1** | **◀️** | - | **Grau** | **Zu Browser** |
| [5] Screen Share | 🖥️ | Ctrl+Alt+E | Orange | Screen Sharing starten |
| [6] Unshare | 🖥️ | Ctrl+Alt+E | Grau | Screen Sharing beenden |
| [7] Hangup | ☎️ | Escape | Dunkelrot | Anruf beenden |
| [8] Raise Hand | ✋ | Ctrl+Shift+K | Gelb | Hand heben (Meeting) |
| [9] Chat | 💬 | Ctrl+Shift+O | Hellblau | Chat öffnen |

**Meeting-Shortcut:**
- `[0]` Mute + `[2]` Cam On → In Meeting gehen
- `[5]` Screen Share → Code zeigen
- `[7]` Hangup → Fertig!

---

## 🚀 Deploy-Buttons: URLs konfigurieren

Buttons [5] und [6] auf Seite 1 öffnen je 4 URLs nacheinander.

### Deine URLs eintragen

Öffne `streamdeck-config.js` und trage unter `urls` ein:

```javascript
urls: {
  deployQa: [
    'https://qa-dashboard.example.com',
    'https://qa-logs.example.com',
    'https://qa-monitoring.example.com',
    'https://qa-deploy.example.com',
  ],
  deployDev: [
    'https://dev-dashboard.example.com',
    'https://dev-logs.example.com',
    'https://dev-monitoring.example.com',
    'https://dev-deploy.example.com',
  ]
}
```

### Test
```bash
npm start
```
→ Seite 1 → Button [5] oder [6] → Alle 4 URLs öffnen sich (mit 500ms Verzögerung)

---

## ⚙️ Anpassungen

### Hotkey ändern

`streamdeck-config.js` → `pages.page2[0]` (z.B. Format Code):

```javascript
{
  index: 0,
  name: 'Format Code',
  hotkey: { key: 'l', modifiers: ['ctrl', 'alt'] },  // ← Hier ändern
}
```

### Command ändern (Teams/Outlook öffnen)

`streamdeck-config.js` → `pages.page1[0]` (Teams öffnen):

```javascript
{
  index: 0,
  name: 'Teams Open',
  command: 'start ms-teams:',  // ← Hier ändern
}
```

### Farbe ändern

```javascript
color: { r: 255, g: 0, b: 0 }  // RGB (0-255)
```

---

## 🎨 Icons neu generieren

```bash
npm run icons
```

→ Alle Icons werden aus den Emojis neu erstellt

---

## 📋 Alle Standard-Hotkeys (IntelliJ)

| Shortcut | Was es tut |
|----------|-----------|
| **Ctrl+Alt+L** | Code formatieren |
| **Ctrl+Alt+O** | Imports optimieren |
| **Alt+Return** | Intention Actions / Quick Fixes |
| **F10** | Run |
| **Ctrl+T** | Update Project (VCS) |
| **Ctrl+Shift+K** | Push |
| **Ctrl+\** | GitHub Copilot |
| **F9** | Debug |
| **Ctrl+H** | Find & Replace |

---

## 📋 Alle Standard-Hotkeys (Teams)

| Shortcut | Was es tut |
|----------|-----------|
| **Ctrl+M** | Mute / Unmute |
| **Ctrl+K** | Cam an / aus |
| **Ctrl+Alt+E** | Screen Share toggle |
| **Escape** | Hangup |
| **Ctrl+Shift+K** | Raise Hand |
| **Ctrl+Shift+O** | Chat öffnen |

---

## 🐛 Troubleshooting

### Hotkeys funktionieren nicht
- **Fenster muss aktiv sein!** (Teams/IntelliJ muss fokussiert sein)
- Hotkey manuell testen (Ctrl+M in Teams-Fenster drücken)

### Teams/Outlook lässt sich nicht öffnen
- Falls nicht installiert: Einfach in `streamdeck-config.js` entfernen oder anders konfigurieren
- Alternative: `command: 'start chrome'` für Chrome statt Edge

### Icons fehlen
```bash
npm run icons
```

### Seite wechsel funktioniert nicht
- Button [4] auf jeder Seite = Navigationsbuttonr
- Sollte automatisch funktionieren, Check ob Controller läuft

---

## 📝 Notizen

- **3 Seiten à 5x3 = 15 Buttons** (alle Buttons genutzt!)
- **Page-Navigation:** Button [4] auf Seite 1 & 2, Button [4] auf Seite 3
- **Verzögerung zwischen URLs:** 500ms (anpassbar im Controller)
- **Kein Admin nötig** – läuft als normales Node.js Script

---

**Happy Streaming! 🚀**
