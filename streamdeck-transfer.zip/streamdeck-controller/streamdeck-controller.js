// streamdeck-controller.js
const { openStreamDeck } = require('elgato-stream-deck');
const robot = require('robotjs');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const config = require('./streamdeck-config');

console.log('🎮 Streamdeck Controller mit Multi-Page-Support starten...');

let streamDeck;
try {
  streamDeck = openStreamDeck();
  console.log('✅ Streamdeck verbunden!');
} catch (err) {
  console.error('❌ Streamdeck nicht gefunden:', err.message);
  process.exit(1);
}

// Aktuelle Seite (0 = page1, 1 = page2, 2 = page3)
let currentPage = 0;
const pageNames = ['🌐 Browser & Deploy', '💻 IntelliJ', '📞 Teams'];

// Button-Status
const buttonStates = {};

function loadPage(pageNum) {
  if (pageNum < 0 || pageNum > 2) return;
  
  currentPage = pageNum;
  const pageKey = `page${pageNum + 1}`;
  const buttons = config.pages[pageKey];
  
  console.log(`\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`📄 PAGE ${pageNum + 1}: ${pageNames[pageNum]}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
  
  buttons.forEach(btn => {
    if (btn.icon && fs.existsSync(btn.icon)) {
      try {
        const iconBuffer = fs.readFileSync(btn.icon);
        streamDeck.fillImage(btn.index, iconBuffer);
        console.log(`  ✅ [${btn.index.toString().padEnd(2)}] ${btn.name.padEnd(20)} (Icon)`);
      } catch (err) {
        streamDeck.fillColor(btn.index, btn.color.r, btn.color.g, btn.color.b);
        console.log(`  ⚠️  [${btn.index.toString().padEnd(2)}] ${btn.name.padEnd(20)} (Farbe)`);
      }
    } else {
      streamDeck.fillColor(btn.index, btn.color.r, btn.color.g, btn.color.b);
      console.log(`  ✅ [${btn.index.toString().padEnd(2)}] ${btn.name.padEnd(20)} (Farbe)`);
    }
    buttonStates[btn.index] = false;
  });
  
  console.log(`\n⌨️  Bereit zum Drücken...\n`);
}

// Initiale Seite laden
loadPage(0);

// Button-Presses abfangen
streamDeck.on('down', (keyIndex) => {
  const pageKey = `page${currentPage + 1}`;
  const buttons = config.pages[pageKey];
  const button = buttons.find(b => b.index === keyIndex);
  
  if (!button) {
    console.log(`⚠️  Button ${keyIndex} nicht konfiguriert`);
    return;
  }

  console.log(`\n▶️  [S${currentPage + 1}:B${keyIndex}] ${button.name}`);
  
  // Page Switch
  if (button.type === 'page') {
    loadPage(button.targetPage);
    flashButtonColor(keyIndex, button.color);
    return;
  }
  
  // Hotkey ausführen
  if (button.hotkey) {
    executeHotkey(button.hotkey);
  }
  
  // Command ausführen
  if (button.command) {
    executeCommand(button.command);
  }

  // URLs öffnen
  if (button.type === 'multiurl' && button.urls) {
    openMultipleUrls(config.urls[button.urls], button.name);
  }
  
  // Feedback
  if (button.icon && fs.existsSync(button.icon)) {
    flashButtonIcon(keyIndex, button.icon, button.color);
  } else {
    flashButtonColor(keyIndex, button.color);
  }
});

/**
 * Hotkey ausführen (Ctrl+M, etc.)
 */
function executeHotkey(hotkey) {
  try {
    const modifiers = hotkey.modifiers || [];
    robot.keyTap(hotkey.key, modifiers);
    const modStr = modifiers.length > 0 ? modifiers.join('+') + '+' : '';
    console.log(`  ⌨️  Hotkey: ${modStr}${hotkey.key}`);
  } catch (err) {
    console.error(`  ❌ Hotkey-Fehler: ${err.message}`);
  }
}

/**
 * Windows-Command ausführen
 */
function executeCommand(command) {
  try {
    execSync(command, { windowsHide: true, stdio: 'ignore' });
    console.log(`  💻 Command ausgeführt`);
  } catch (err) {
    console.error(`  ❌ Command-Fehler: ${err.message}`);
  }
}

/**
 * Mehrere URLs mit Verzögerung öffnen
 */
function openMultipleUrls(urls, buttonName) {
  if (!urls || urls.length === 0) {
    console.log(`  ⚠️  Keine URLs konfiguriert für ${buttonName}`);
    return;
  }

  console.log(`  🌐 Öffne ${urls.length} URLs...`);
  
  urls.forEach((url, index) => {
    setTimeout(() => {
      try {
        execSync(`start ${url}`, { windowsHide: true, stdio: 'ignore' });
        console.log(`    ✅ [${index + 1}/${urls.length}]`);
      } catch (err) {
        console.error(`    ❌ URL ${index + 1}: ${err.message}`);
      }
    }, index * 500);
  });
}

/**
 * Icon-Button blinken
 */
function flashButtonIcon(index, iconPath, color) {
  const dimColor = { 
    r: Math.floor(color.r / 3), 
    g: Math.floor(color.g / 3), 
    b: Math.floor(color.b / 3) 
  };
  streamDeck.fillColor(index, dimColor.r, dimColor.g, dimColor.b);
  
  setTimeout(() => {
    try {
      const iconBuffer = fs.readFileSync(iconPath);
      streamDeck.fillImage(index, iconBuffer);
    } catch {
      streamDeck.fillColor(index, color.r, color.g, color.b);
    }
  }, 150);
}

/**
 * Farb-Button blinken
 */
function flashButtonColor(index, color) {
  const dimColor = { 
    r: Math.floor(color.r / 3), 
    g: Math.floor(color.g / 3), 
    b: Math.floor(color.b / 3) 
  };
  
  streamDeck.fillColor(index, dimColor.r, dimColor.g, dimColor.b);
  setTimeout(() => {
    streamDeck.fillColor(index, color.r, color.g, color.b);
  }, 150);
}

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n\n👋 Streamdeck Controller beendet');
  streamDeck?.close();
  process.exit(0);
});
